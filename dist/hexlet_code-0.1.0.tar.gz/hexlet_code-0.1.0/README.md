### Hexlet tests and linter status:
[![Actions Status](https://github.com/goryay/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/goryay/python-project-50/actions)
<a href="https://codeclimate.com/github/goryay/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/614a3f8511bdb84b3258/maintainability" /></a>
<a href="https://codeclimate.com/github/goryay/python-project-lvl1/test_coverage"><img src="https://api.codeclimate.com/v1/badges/614a3f8511bdb84b3258/test_coverage" /></a>

